Android মোবাইলের জন্য Binary Signal Prototype
============================================

ফাইল:
- app.py: Streamlit অ্যাপ
- requirements.txt: প্রয়োজনীয় Python প্যাকেজ

মোবাইল দিয়ে প্রকাশ:
1. GitHub-এ লগইন করুন এবং নতুন repository তৈরি করুন।
2. app.py ও requirements.txt আপলোড করুন।
3. https://share.streamlit.io/ খুলে GitHub দিয়ে লগইন করুন।
4. Create app চাপুন; repository নির্বাচন করুন; app.py বেছে Deploy দিন।
5. অ্যাপ খুলে Alpha Vantage API key লিখুন।

গুরুত্বপূর্ণ:
- Alpha Vantage-এর 1-minute FX_INTRADAY access আপনার প্ল্যান অনুযায়ী সীমিত/পেইড হতে পারে।
- API key GitHub-এ রাখবেন না; ব্যক্তিগত রাখুন।
- OTC নির্বাচন করলে সিগন্যাল বন্ধ থাকবে, কারণ broker-specific OTC feed যুক্ত নেই।
- BUY/SELL হলো সাধারণ নিয়মভিত্তিক demo, লাভ বা accuracy-এর নিশ্চয়তা নয়।
- এই প্রোটোটাইপ স্বয়ংক্রিয়ভাবে কোনো ট্রেড করে না।
